<template>
  <div class="home container">
    <div class="main" v-for="item in getInfo">
          <div class="main row" v-for="data in item.links">
            <img class="" :src="data.href" alt="">
          </div>
    </div>
  </div>
</template>


<style media="screen">
  .home{
    margin-top: 10vh;
  }
  .main{
    display: inline!important;
  }
  img{
    width: 30vw;
    height: 40vh;
  }
</style>
<script>
  export default {
    data(){
  return{
   }
},
  computed:{
    getInfo(){
      return this.$store.state.info;
    },
    getCenterInInfo(){
      //console.log(this.$store.state.info.map(data=>data.data.map(item=>item.center)));
      console.log(this.$store.state.info.map(data=>data.links));
      return this.$store.state.info.map(data=>data.data.map(item=>item.center));
    },
    getImages(){
      console.log(this.$store.state.info.map(data=>data.links));
      return this.$store.state.info.map(data=>data.links);
    }
  },
}
</script>
